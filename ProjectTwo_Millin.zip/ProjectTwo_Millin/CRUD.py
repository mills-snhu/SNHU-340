from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):
    
    def __init__(self):        
        USER = 'aacuser'
        PASS = 'Smilax25'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32275
        DB = 'AAC'
        COL = 'animals'
        
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        
     #Method to create object inserted into database/ collection
    def create(self, data):
        if data is not None:
            insert = self.database.animals.insert_one(data)
            
            return True if insert.acknowledged else False  #True confirms insertion of data
              
        else:
            raise Exception("Nothing to save, because data parameter is emptpy")
            
    #Read method to find a document with certain data       
    def read(self, data):
        if data is not None:
            document = self.database.animals.find(data, {'_id': False})
            
        else:
            document = self.database.animals.find({},{'_id': False})  #not successful query returns an empty list 
            
        return document
    
    #update method to update the collection
    def update(self, findQuery, updateData):
        if findQuery is not None:
            document = self.database.animals.update_one(findQuery, {"$set": updateData})
            return True if document.acknowledged else False
        else:
            return"{}"
        return document
        
    #delete method to delete from the collection
    def delete(self,data):
        if data is not None:
            document = self.database.animals.delete_one(data)
            
        else:
            return "{}"
        
        return document.raw_result
            